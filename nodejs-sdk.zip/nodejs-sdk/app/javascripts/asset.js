module.exports = {
hexCharCodeToStr: function (hexCharCodeStr) {
    const trimedStr = hexCharCodeStr.trim()
    const rawStr = trimedStr.substr(0, 2).toLowerCase() === '0x' ? trimedStr.substr(2) : trimedStr
    const len = rawStr.length
    if (len % 2 !== 0) {
        window.alert(' Illegal Format ASCII Code!')
        return ''
    }
    let curCharCode
    const resultStr = []
    for (let i = 0; i < len; i = i + 2) {
        curCharCode = parseInt(rawStr.substr(i, 2), 16) // ASCII Code Value
        resultStr.push(String.fromCharCode(curCharCode))
    }
    return resultStr.join('')
},
//register(myInstance, account, type)
register:function(myInstance,account){
 const myaccount = document.getElementById('account').value
 const amount = document.getElementById('amount').value
 const type = document.getElementById('type').value
 console.log(account + ' ' + amount + ' ' + type)
 myInstance.register(account, amount, type,{ from: account, gas: 3000000 }).then(function () {
    myInstance.register(function (e, r) {
      if (!e) {
        console.log(r)
        console.log(r.args)
        if (r.args.isSuccess === true) {
          window.App.setStatus('注册成功')
        } else {
          window.App.setStatus('账户已经注册')
        }
      } else {
        console.log(e)
      }
    })
  })

}	

}
