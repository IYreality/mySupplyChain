// Import libraries 
//const asset = require('./asset')
var express = require("express")
var net = require("net")
var http = require("http")
//const Web3jService = require("../../packages/api/web3j").Web3jService

var abi =[{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"receipts","outputs":[{"name":"Arrears","type":"string"},{"name":"Payee","type":"string"},{"name":"amount","type":"uint256"},{"name":"finished","type":"bool"},{"name":"status","type":"bool"},{"name":"owner","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"amount","type":"uint256"},{"name":"id","type":"uint256"}],"name":"payoff","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"amount","type":"uint256"}],"name":"issue","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"id","type":"uint256"}],"name":"finance","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"id","type":"uint256"},{"name":"status","type":"bool"}],"name":"response","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"account","type":"string"},{"name":"asset_value","type":"uint256"},{"name":"ctype","type":"bool"}],"name":"register","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"id","type":"uint256"}],"name":"passCredit","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"from_account","type":"string"},{"name":"to_account","type":"string"},{"name":"amount","type":"uint256"}],"name":"check","outputs":[{"name":"","type":"int256"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"account","type":"string"}],"name":"select","outputs":[{"name":"","type":"int256"},{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"name":"ret","type":"int256"},{"indexed":true,"name":"account","type":"string"},{"indexed":true,"name":"asset_value","type":"uint256"}],"name":"RegisterEvent","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"ret","type":"int256"},{"indexed":true,"name":"from_account","type":"string"},{"indexed":true,"name":"to_account","type":"string"},{"indexed":true,"name":"amount","type":"uint256"}],"name":"RequestEvent","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"ret","type":"int256"},{"indexed":true,"name":"from_account","type":"string"},{"indexed":true,"name":"to_account","type":"string"},{"indexed":true,"name":"amount","type":"uint256"}],"name":"TransferEvent","type":"event"}];
var contractAddress = "0x16f9e76c0cfbec1d3a2784e8da7280b04c070f1a"

//import artifacts from '../../packages/cli/contracts/Asset'

//let myContract = web3.eth.contract(abi).at(contractAddress);
const web3jService = require('../../packages/api').Web3jService;
//let web3jService = new Web3jService();

var server = http.createServer(app).listen(port, function () { });
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
server.timeout = 240000;
console.log('\n');
console.log('----------------------------------- Server Up - ' + host + ':' + port + ' -----------------------------------');
process.on('uncaughtException', function (err) {
	logger.error('Caught exception: ', err.stack);		// marbles never gives up! (this is bad practice, but its just a demo)
	if (err.stack.indexOf('EADDRINUSE') >= 0) {			// well, except for this error
		logger.warn('---------------------------------------------------------------');
		logger.warn('----------------------------- Ah! -----------------------------');
		logger.warn('---------------------------------------------------------------');
		logger.error('You already have something running on port ' + port + '!');
		logger.error('Kill whatever is running on that port OR change the port setting in your marbles config file: ' + cp.config_path);
		process.exit();
	}
	if (wss && wss.broadcast) {							// if possible send the error out to the client
		wss.broadcast({
			msg: 'error',
			info: 'this is a backend error!',
			e: err.stack,
		});
	}
});


let myInstance

let amount
let type
let account
let address
let accounts

window.App = {
    init: function () {
        myContract.setProvider(window.web3.currentProvider)
      // Get the initial account balance so it can be displayed.
      window.web3.eth.getAccounts(function (err, accs) {
        if (err != null) {
          window.App.setStatus('There was an error fetching your accounts.')
          return
        }
  
        if (accs.length === 0) {
          window.App.setStatus('Couldn\'t get any accounts! Make sure your Ethereum client is configured correctly.')
          return
        }
        accounts = accs
        account = accounts[0]
      })
  
      myContract.deployed().then(function (instance) {
      myInstance = instance
      }).catch(function (e) {
        console.log(e, null)
      })
    },
    // register
    register: function () {
        var account_val = document.getElementById("account").value;
        var amount_val = document.getElementById("amount").value;
        if(account_val==""){
            alert("用户名不能为空！！");
        }else if(amount_val==""){
            alert("邮箱不能为空！！");
        }
        web3jService.call(account_val,register,account_val,amount_val);
    },
    //set
    setAmount:function(currentAccount){
      web3jService.call(account_val,setAmount,account_val,amount_val);
    },
    compile:function(){
      web3jService.call(account_val,compile,account_val);
    },
    deploy:function(){
      web3jService.call(account_val,deploy,account_val);
    },
    // diaplay
    //get account
    getAccount:function(currentAccount){
      web3jService.call(account_val,showCurrentAccount,account_val);
    },
    // get address
    getScoreWithCustomerAddr: function (currentAccount) {
      web3jService.call(account_val,getScoreWithCustomerAddr,account_val);
    },
      // get ammount
    getScoreWithCustomerAddr: function (currentAccount) {
      web3jService.call(account_val,getScoreWithCustomerAddr,account_val);
      customer.getScoreWithCustomerAddr(currentAccount, ScoreInstance, account)
    },
    // get key
    getScoreWithCustomerAddr: function (currentAccount) {
      web3jService.call(account_val,getScoreWithCustomerAddr,account_val);
      customer.getScoreWithCustomerAddr(currentAccount, ScoreInstance, account)
    },
    // get block
    getBlockNumber:function(){
      Web3jService.getBlockNumber().then(blockNumber=>{
        console.log(blockNumber)
      });
    },
    //transfer
    transfer: function (currentAccount) {
      web3jService.call(account_val,getScoreWithCustomerAddr,account_val);
    },
    // issue
    issue: function (currentAccount) {
      web3jService.call(account_val,getScoreWithCustomerAddr,account_val);
    },
    // response
    response: function (currentAccount) {
      web3jService.call(account_val,response,account_val);
    },
    // passCredit
    passCredit: function (currentAccount) {
      web3jService.call(account_val,passCredit,account_val);
    },
    // finance
    finance: function () {
      web3jService.call(account_val,finance,account_val);
    },
    // payoff
    payoff: function () {
      web3jService.call(account_val,payoff,id);
    },
    // query all blockchain user
    allAccounts: function () {
      let allAccount = ''
      window.web3.eth.accounts.forEach(e => {
        allAccount += e + '\n'
      })
      window.App.setConsole(allAccount)
    },
    // display
    setStatus: function (message) {
      const status = document.getElementById('status')
      status.innerHTML = message
    },
    // diaplayconsole
    setConsole: function (message) {
      const status = document.getElementById('console')
      status.innerHTML = message
    }
    
  
  }

  
  window.addEventListener('load', function () {
    // connect web3 http://127.0.0.1:8080
    window.web3 = new Web3(new Web3.providers.HttpProvider('http://127.0.0.1:8080'))
    window.App.init()
  })
  
  
