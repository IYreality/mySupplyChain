package main

import (
	"encoding/json"
	"errors"
	"strconv"
)

func register(stub shim.ChaincodeStubInterface, id string) (Asset, error) {
	var asset Asset
	AssetAsBytes, err := stub.GetState(id)                 
	if err != nil {                                        
		return marble, errors.New("Failed to register - " + id)
	}
	json.Unmarshal(marbleAsBytes, &marble)                

	if marble.Id != id {                                     
		return marble, errors.New("Asset does not exist - " + id)
	}

	return marble, nil
}
func set_amount(stub shim.ChaincodeStubInterface,id string)(Owner,error){
	var owner Owner
	return;	
}

func get_owner(stub shim.ChaincodeStubInterface, id string) (Owner, error) {
	var owner Owner
	ownerAsBytes, err := stub.GetState(id)              
	if err != nil {                                            
		return owner, errors.New("Failed to get owner - " + id)
	}
	json.Unmarshal(ownerAsBytes, &owner)                      

	if len(owner.Username) == 0 {                            
		return owner, errors.New("Owner does not exist - " + id + ", '" + owner.Username + "' '" + owner.Company + "'")
	}
	
	return owner, nil
}


